<?php

/**
 * @version    4.0.0
 * @package    com_ra_mailman
 * @author     Charlie Bigley <webmaster@bigley.me.uk>
 * @copyright  2023 Charlie Bigley
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Ramblers\Component\Ra_mailman\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;
use Ramblers\Component\Ra_mailman\Site\Helpers\UserHelper;
use Ramblers\Component\Ra_tools\Site\Helpers\ToolsHelper;

/**
 * Profiles list controller class.
 *
 * @since  4.0.0
 */
class ProfilesController extends AdminController {

    protected $back = 'index.php?option=com_ra_tools&view=dashboard';

    public function cancel($key = null, $urlVar = null) {
        $this->setRedirect($this->back);
    }

    /**
     * Proxy for getModel.
     *
     * @param   string  $name    Optional. Model name
     * @param   string  $prefix  Optional. Class prefix
     * @param   array   $config  Optional. Configuration array for model
     *
     * @return  object	The Model
     *
     * @since   4.0.0
     */
    public function getModel($name = 'Profile', $prefix = 'Administrator', $config = array()) {
        return parent::getModel($name, $prefix, array('ignore_request' => true));
    }

    public function back() {
        $this->setRedirect($this->back);
    }

    public function load($code = 'NS03') {
        // temp code for invoking the load process
        $code = $this->app->input->getAlnum('code');
        $loadHelper = new \Ramblers\Component\Ra_mailman\Site\Helpers\LoadHelper;
        $result = $loadHelper->loadMembers($code);
echo 'After loadMembers<br>';
        foreach ($loadHelper->messages as $message) {
             echo $message . '<br>';
        }   
        die;
        if ($result === true) {
            $this->setMessage(Text::_('COM_RA_MAILMAN_LOAD_SUCCESS'), 'success');
        } else {
            $this->setMessage(Text::_('COM_RA_MAILMAN_LOAD_FAILURE'), 'error');
        }

        $this->setRedirect($this->back);
    }   

    public function purgeTestdata() {
        echo 'Not implemented<br>';

        $wa = Factory::getApplication()->getDocument()->getWebAssetManager();
        $wa->registerAndUseStyle('ramblers', 'com_ra_tools/ramblers.css');
        $objToolsHelper = new ToolsHelper;
        $objUserHelper = new UserHelper;
//        $objUserHelper->purgeTestData();
        echo $objToolsHelper->backButton('administrator/' . $this->back);
    }

}
